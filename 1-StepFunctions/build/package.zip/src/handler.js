(function(e, a) { for(var i in a) e[i] = a[i]; }(exports, /******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = 1);
/******/ })
/************************************************************************/
/******/ ([
/* 0 */
/***/ (function(module, exports) {

module.exports = require("aws-sdk");

/***/ }),
/* 1 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);

// CONCATENATED MODULE: ./src/lib/util.js
const sleep = ms => new Promise((resolve, reject) => {
  setTimeout(resolve, ms);
});
// EXTERNAL MODULE: external "aws-sdk"
var external_aws_sdk_ = __webpack_require__(0);
var external_aws_sdk_default = /*#__PURE__*/__webpack_require__.n(external_aws_sdk_);

// CONCATENATED MODULE: ./src/lib/sf.js


const startThenWait = async (stateMachineArn, input) => {
  // busy-wait for the execution to finish running
  // This isn't really a good idea; you're better off add additional steps to
  // the state machine that do things like update DB entries etc
  const sf = new external_aws_sdk_default.a.StepFunctions({
    region: process.env.REGION
  });
  const params = {
    stateMachineArn,
    input: JSON.stringify(input)
  };
  const {
    executionArn
  } = await sf.startExecution(params).promise();

  while (true) {
    const {
      status,
      output,
      ...other
    } = await sf.describeExecution({
      executionArn
    }).promise();

    if (status === 'RUNNING') {
      await sleep(5);
    } else {
      if (status === 'SUCCEEDED') {
        console.log({
          status,
          output,
          other
        });
        return JSON.parse(output).message;
      } else {
        throw new Error(`State Machine status ${status}`);
      }
    }
  }
};
// CONCATENATED MODULE: ./src/lib/welcome.js



const randomIndex = max => Math.floor(Math.random() * max);

const messages = ['Hello World', 'Welcome', 'Sawubona Umhlaba'];

class WelcomeError extends Error {
  constructor(message) {
    super();
    this.name = 'WelcomeError';
    this.message = message;
    this.statusCode = 500;
  }

}

const get = async () => {
  await sleep(Math.random() * 3000); // const messageCount = messages.length

  const messageCount = 6;
  const message = messages[randomIndex(messageCount)];

  if (!message) {
    throw new WelcomeError('Could not get welcome');
  }

  return message;
};
const getWithRetry = async () => {
  return startThenWait(process.env.WELCOME_RETRY_STATE_MACHINE, {
    test: 'test input'
  });
};
// CONCATENATED MODULE: ./src/handler.js
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getWelcome", function() { return getWelcome; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getWelcomeHttp", function() { return getWelcomeHttp; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getWelcomeWithRetry", function() { return getWelcomeWithRetry; });

const getWelcome = async (event, context, callback) => {
  try {
    const message = await get();
    callback(null, {
      message
    });
  } catch (e) {
    console.error(e);
    callback(e);
  }
};
const getWelcomeHttp = async (event, context, callback) => {
  try {
    const message = await get();
    callback(null, {
      statusCode: 200,
      body: JSON.stringify({
        message
      })
    });
  } catch (e) {
    console.error(e);
    const {
      statusCode,
      message: error
    } = e;
    callback(null, {
      statusCode,
      body: JSON.stringify({
        error
      })
    });
  }
};
const getWelcomeWithRetry = async (event, context, callback) => {
  try {
    const message = await getWithRetry();
    callback(null, {
      statusCode: 200,
      body: JSON.stringify({
        message
      })
    });
  } catch (e) {
    console.error(e);
    const {
      statusCode,
      message: error
    } = e;
    callback(null, {
      statusCode,
      body: JSON.stringify({
        error
      })
    });
  }
};

/***/ })
/******/ ])));